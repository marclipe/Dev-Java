package minhaclasse;

public class Superior extends Classes {

    public float GetSuperior() {
        media = (float) (n1 * 0.35 + n2 * 0.5 + n3 * 0.15);
        return media;
    }
}
