package minhaclasse;

public class Tecnico extends Classes{

    public float GetTecnico() {
        media = (n1 + n2 * 2 + n3 * 2) / 5;
        return media;
    }

}
