package minhaclasse;

public class Main extends minhaclasse.Classes {

    public double GetMediaTe() {
        media = (N1 + N2*2 + N3*2)/5;
        return media;
    }
}
